public class Solver {

	public static String[] answer() {
		String[] kaitou = new String[Data.numdata];

		for(int i=0; i<Data.numdata; i++){
			kaitou[i]="C1";
		}

		return kaitou;
	}

}
